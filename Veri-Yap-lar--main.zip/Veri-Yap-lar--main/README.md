# Veri Yapıları
 kütüphane otomasyonu
